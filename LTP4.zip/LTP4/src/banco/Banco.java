package banco;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dados.Pessoa;
import erro.PessoaException;

public class Banco
{
    /*private static final String DB_USERNAME = "SYSDBA";
    private static final String DB_PASSWORD  = "masterkey";
    private static final String DB_URL = "jdbc:firebirdsql:server1b/3050:D:/PROGRAM FILES/FIREBIRD/LTP4/";
    private static final String DB_NAME = "BDPESSOAS.GDB";*/

    private static Connection conexao = null;
    private static PreparedStatement comando = null;
    private static ResultSet dataSet = null;

    /**
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    private void AbrirFecharConexao() throws SQLException, ClassNotFoundException
    {
        if(conexao == null)
        {
        	Class.forName("org.firebirdsql.jdbc.FBDriver");
        	conexao = DriverManager.getConnection("jdbc:firebirdsql:server1b/3050:D:/PROGRAM FILES/FIREBIRD/LTP4/BDPESSOAS.GDB", "SYSDBA", "masterkey");	

            /*DriverManager.registerDriver( new org.firebirdsql.jdbc.FBDriver());*/
            //conexao = DriverManager.getConnection(DB_URL + DB_NAME, DB_USERNAME, DB_PASSWORD);
            /*conexao = DriverManager.getConnection("jdbc:firebirdsql:server1b/3050:D:/PROGRAM FILES/FIREBIRD/LTP4/BDPESSOAS.GDB", "SYSDBA", "masterkey");*/
        }
        else
        {
            conexao.close();
            conexao = null;
        }
    }

    /**
     * @param p
     * @throws PessoaException
     * @throws ClassNotFoundException 
     */
    public void CadastrarPessoa(Pessoa p) throws PessoaException, ClassNotFoundException
    {
        try
        {
            AbrirFecharConexao();

            comando = conexao.prepareStatement("SELECT nome, nascimento FROM agenda WHERE nome = ? AND nascimento = ?");
            comando.setString(1, p.getNome());
            comando.setDate(2, p.getNascimento());
            dataSet = comando.executeQuery();
            if(dataSet.next())
            {
            	throw new PessoaException("J� existe no cadastro uma pessoa com o mesmo nome e data de nascimento.");
            }

            comando = conexao.prepareStatement("INSERT INTO agenda (nome, telefone, nascimento, email) VALUES (?, ?, ?, ?)");
            comando.setString(1, p.getNome());
            comando.setString(2, p.getTelefone());
            comando.setDate(3, p.getNascimento());
            comando.setString(4, p.getEmail());
            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            throw new PessoaException(e);
        }
    }

    /**
     * @param p
     * @throws PessoaException
     * @throws ClassNotFoundException 
     */
    public void AlterarPessoa(Pessoa p) throws PessoaException, ClassNotFoundException
    {
        try
        {
            AbrirFecharConexao();
            comando = conexao.prepareStatement("UPDATE agenda SET nome = ?, telefone = ?, nascimento = ?, email = ? WHERE codigo = ?");
            comando.setString(1, p.getNome());
            comando.setString(2, p.getTelefone());
            comando.setDate(3, p.getNascimento());
            comando.setString(4, p.getEmail());
            comando.setInt(5, p.getCodigo());
            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            throw new PessoaException(e);
        }
    }

    /**
     * @param cod
     * @throws PessoaException
     * @throws ClassNotFoundException 
     */
    public void ApagarPessoa(int cod) throws PessoaException, ClassNotFoundException
    {
        try
        {
            AbrirFecharConexao();
            comando = conexao.prepareStatement("DELETE FROM agenda WHERE codigo = ?");
            comando.setInt(1, cod);
            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            throw new PessoaException(e);
        }
    }

    /**
     * @param cod
     * @return Pessoa
     * @throws PessoaException
     */
    @SuppressWarnings("finally")
    public Pessoa ConsultarPessoa(int cod) throws PessoaException
    {
        Pessoa p = null;
        try
        {
            AbrirFecharConexao();
            comando = conexao.prepareStatement("SELECT nome, telefone, nascimento, email FROM agenda WHERE codigo = ? ORDER BY nome, nascimento DESC");
            comando.setInt(1, cod);
            dataSet = comando.executeQuery();
            p = new Pessoa(dataSet.getString("nome"), dataSet.getString("telefone"), dataSet.getDate("nascimento"), dataSet.getString("email"));
            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            new PessoaException("N�o existe pessoa para o c�digo informado.");
        }
        finally
        {
            return p;
        }
    }

    /**
     * @param nome
     * @return ArrayList<Pessoa>
     * @throws PessoaException
     */
    @SuppressWarnings("finally")
    public ArrayList<Pessoa> ConsultarPessoaPeloNome(String nome) throws PessoaException
    {
        ArrayList<Pessoa> retorno = new ArrayList<Pessoa>();
        try
        {
            AbrirFecharConexao();
            comando = conexao.prepareStatement("SELECT nome, telefone, nascimento, email FROM agenda WHERE nome LIKE '?%' ORDER BY nome, nascimento DESC");
            comando.setString(1, nome);
            dataSet = comando.executeQuery();

            while(dataSet.next())
            {
                retorno.add(new Pessoa(dataSet.getString("nome"), dataSet.getString("telefone"), dataSet.getDate("nascimento"), dataSet.getString("email")));
            }

            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            new PessoaException("N�o existe nenhuma pessoa para o nome informado.");
        }
        finally
        {
            return retorno;
        }
    }

    /**
     * @param mes
     * @return ArrayList<Pessoa>
     * @throws PessoaException
     */
    @SuppressWarnings("finally")
    public ArrayList<Pessoa> ConsultarPessoaPeloMes(int mes) throws PessoaException
    {
        ArrayList<Pessoa> retorno = new ArrayList<Pessoa>();;
        try
        {
            AbrirFecharConexao();
            comando = conexao.prepareStatement("SELECT nome, telefone, nascimento, email FROM agenda WHERE MONTH(nascimento) = ? ORDER BY nome, nascimento DESC");
            comando.setInt(1, mes);
            dataSet = comando.executeQuery();

            while(dataSet.next())
            {
                retorno.add(new Pessoa(dataSet.getString("nome"), dataSet.getString("telefone"), dataSet.getDate("nascimento"), dataSet.getString("email")));
            }

            AbrirFecharConexao();
        }
        catch (SQLException e)
        {
            new PessoaException("N�o existe nenhuma pessoa para o m�s de nascimento informado.");
        }
        finally
        {
            return retorno;
        }
    }
}
