package dados;

import java.sql.Date;

public class Pessoa
{
    private int codigo;
    private String nome;
    private String telefone;
    private java.sql.Date nascimento;
    private String email;

    /**
     * @return nome
     */
    public String getNome()
    {
        return nome;
    }

    /**
     * @param nome
     */
    public void setNome(String nome)
    {
        this.nome = nome;
    }

    /**
     * @return telefone
     */
    public String getTelefone()
    {
        return telefone;
    }

    /**
     * @param telefone
     */
    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    /**
     * @return nascimento
     */
    public java.sql.Date getNascimento()
    {
        return nascimento;
    }

    /**
     * @param nascimento
     */
    public void setNascimento(java.sql.Date nascimento)
    {
        this.nascimento = nascimento;
    }
    /**
     * @return email
     */
    public String getEmail()
    {
        return email;
    }

    /**
     * @param email
     */
    public void setEmail(String email)
    {
        this.email = email;
    }

    /**
     * @return codigo
     */
    public int getCodigo()
    {
        return codigo;
    }

    /**
     * @param nome
     * @param telefone
     * @param nascimento
     * @param email
     */
    public Pessoa(String nome, String telefone, Date nascimento, String email)
    {
        super();
        this.nome = nome;
        this.telefone = telefone;
        this.nascimento = nascimento;
        this.email = email;
    }

    @Override
    public String toString()
    {
        return "Dados da Pessoa: C�digo = " + codigo + ", nome = " + nome + ", telefone = " + telefone + ", nascimento = " + nascimento
                + ", email = " + email + ".";
    }
}
