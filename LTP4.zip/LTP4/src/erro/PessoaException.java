package erro;

import java.sql.SQLException;

@SuppressWarnings("serial")
public class PessoaException extends Exception
{
    public PessoaException()
    {
        super();
    }

    /**
     * @param e
     */
    public PessoaException(SQLException e)
    {
        super(e);
    }

    /**
     * @param e
     */
    public PessoaException(String e)
    {
        super(e);
    }
}