package usuario;

import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import banco.Banco;
import dados.Pessoa;
import erro.PessoaException;
import utilitarios.LtpUtil;

public class Usuario
{
    private static Banco banco = new Banco();

    /**
     * @param args
     * @throws PessoaException
     * @throws ParseException
     */
    public static void main(String[] args) throws PessoaException, ParseException
    {
    	while(true)
    	{
	        switch (Menu())
	        {
	            case 1:
	                NovaPessoa(utilitarios.Console.readLine("Informe o nome da Pessoa: "));
	                break;
	            case 2:
	                AlterarPessoa(utilitarios.Console.readInt("Informe o c�digo da Pessoa: "));
	                break;
	            case 3:
	                ExcluirPessoa(utilitarios.Console.readInt("Informe o c�digo da Pessoa: "));
	                break;
	            case 4:
	                ConsultarCod(utilitarios.Console.readInt("Informe o c�digo da Pessoa: "));
	                break;
	            case 5:
	                ConsultarNome(utilitarios.Console.readLine("Informe o nome da Pessoa: "));
	                break;
	            case 6:
	                ConsultarMes(utilitarios.Console.readInt("Informe o m�s de nascimento da Pessoa: "));
	                break;
	            default:
	                System.exit(0);
	                break;
	        }
    	}
    }

    /**
     * @return int Opção escolhida pelo usuário
     */
    private static int Menu()
    {
        System.out.println("|-----------------------------------------|");
        System.out.println("| 1 - Incluir Pessoa                      |");
        System.out.println("| 2 - Alterar Pessoa                      |");
        System.out.println("| 3 - Excluir Pessoa                      |");
        System.out.println("| 4 - Consultar pelo c�digo               |");
        System.out.println("| 5 - Consultar pelo nome                 |");
        System.out.println("| 6 - Consultar pelo m�s de nascimento    |");
        System.out.println("|-----------------------------------------|");

        return utilitarios.Console.readInt("Informe o c�digo da op��o desejada: ");
    }

    /**
     * @param nome
     * @throws PessoaException
     * @throws ParseException
     */
    private static void NovaPessoa(String nome) throws PessoaException, ParseException
    {
        try
        {
            String telefone = null, email = null;
            java.sql.Date nascimento = null;

            while(LtpUtil.contarPalavras(nome) < 2)
            {
                nome = utilitarios.Console.readLine("Infome o nome: ").trim();
            }

            do
            {
                telefone = utilitarios.Console.readLine("Infome o telefone: ").trim();
            } while(telefone.length() < 7);

            do
            {
                String temp = utilitarios.Console.readLine("Infome data de nascimento: ").trim();
                DateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
                nascimento = new java.sql.Date(fmt.parse(temp).getTime());
            } while(nascimento == null);

            do
            {
                email = utilitarios.Console.readLine("Infome o email: ").trim();
            } while(email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$;"));

            banco.CadastrarPessoa(new Pessoa(nome, telefone, nascimento, email));
            System.out.println("Pessoa Cadastrada.");
            Menu();
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    /**
     * @param cod
     * @throws PessoaException
     */
    private static void AlterarPessoa(int cod) throws PessoaException
    {
        try
        {
            Pessoa pessoa = banco.ConsultarPessoa(cod);
            System.out.println(pessoa.toString());

            String nome = null, telefone = null, email = null;
            java.sql.Date nascimento = null;

            do
            {
                nome = utilitarios.Console.readLine("Infome o nome: ").trim();
            } while(LtpUtil.contarPalavras(nome) < 2);

            do
            {
                telefone = utilitarios.Console.readLine("Infome o telefone: ").trim();
            } while(telefone.length() < 7);

            do
            {
                String temp = utilitarios.Console.readLine("Infome data de nascimento: ").trim();
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                Date parsed = (Date) format.parse(temp);
                nascimento = new java.sql.Date(parsed.getTime());
            } while(nascimento == null);

            do
            {
                email = utilitarios.Console.readLine("Infome o email: ").trim();
            } while(email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$;"));

            banco.AlterarPessoa(new Pessoa(nome, telefone, nascimento, email));
            System.out.println("Dados da pessoa foram alterados.");
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    /**
     * @param cod
     * @throws PessoaException
     */
    private static void ExcluirPessoa(int cod) throws PessoaException
    {
        try
        {
            Pessoa pessoa = banco.ConsultarPessoa(cod);
            System.out.println(pessoa.toString());

            String confirmacao = utilitarios.Console.readLine("Confirmar a exclusão da Pessoa ?");

            if(confirmacao.toUpperCase().startsWith("S"))
            {
                banco.ApagarPessoa(cod);
                System.out.println("Pessoa excluída.");
            }
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    /**
     * @param cod
     * @throws PessoaException
     */
    private static void ConsultarCod(int cod) throws PessoaException
    {
        try
        {
            Pessoa pessoa = banco.ConsultarPessoa(cod);
            System.out.println(pessoa.toString());
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    /**
     * @param nome
     * @throws PessoaException
     */
    private static void ConsultarNome(String nome) throws PessoaException
    {
        try
        {
            ArrayList<Pessoa> pessoa = banco.ConsultarPessoaPeloNome(nome);
            for (Pessoa p : pessoa)
            {
            	System.out.println(p.toString());
			}
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }

    /**
     * @param mes
     * @throws PessoaException
     */
    private static void ConsultarMes(int mes) throws PessoaException
    {
        try
        {
            ArrayList<Pessoa> pessoa = banco.ConsultarPessoaPeloMes(mes);
            for (Pessoa p : pessoa)
            {
            	System.out.println(p.toString());
			}
        }
        catch (Exception e)
        {
            System.err.println(e.getMessage());
        }
    }
}
